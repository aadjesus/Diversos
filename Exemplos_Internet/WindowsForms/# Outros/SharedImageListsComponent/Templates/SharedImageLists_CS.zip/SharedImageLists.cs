using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace $rootnamespace$
{
  public partial class $safeitemname$ 
  {
    public $safeitemname$()
    {
      InitializeComponent();
    }

    public $safeitemname$(IContainer container)
    {
      container.Add(this);

      InitializeComponent();
    }
  }
}
