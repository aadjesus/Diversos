﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace TFSObjects
{
    public class Chamado
    {
        private WorkItem oWi;

        public Chamado()
        {
        }

        public Chamado(int WorkItemID, string teamProject)
        {
            workItemID = WorkItemID;

            var ts = Utilitarios.ConectaTFS();
            WorkItemStore store = (WorkItemStore)ts.GetService(typeof(WorkItemStore));

            oWi = store.GetWorkItem(workItemID);

            var oWc = store.Query("SELECT [System.Id], [System.WorkItemType], [System.Title], [System.AssignedTo], [System.State] FROM WorkItems WHERE [System.AreaPath] Under '" + oWi.Fields[CoreField.TeamProject].Value.ToString()  + "\' AND  [System.WorkItemType] = 'ParametrosSLA'   ORDER BY [System.Id] DESC");
            if(oWc.Count >0)
            {
                SLAResposta = new TimeSpan(0, int.Parse(oWc[0].Fields["MindServices.SLAResposta"].Value.ToString()), 0);

                SLAAlta = new TimeSpan(0, int.Parse(oWc[0].Fields["MindServices.SlaIncidenteAlta"].Value.ToString()), 0);
                SLAMedia = new TimeSpan(0, int.Parse(oWc[0].Fields["MindServices.SlaIncidenteMedia"].Value.ToString()), 0);
                SLABaixa = new TimeSpan(0, int.Parse(oWc[0].Fields["MindServices.SlaIncidenteBaixa"].Value.ToString()), 0);


                SLAAltaAlta = new TimeSpan(0, int.Parse(oWc[0].Fields["MindServices.SlaProblemaAltaAlta"].Value.ToString()), 0);
                SLAMediaAlta = new TimeSpan(0, int.Parse(oWc[0].Fields["MindServices.SlaProblemaMediaAlta"].Value.ToString()), 0);
                SLABaixaAlta = new TimeSpan(0, int.Parse(oWc[0].Fields["MindServices.SlaProblemaBaixaAlta"].Value.ToString()), 0);

                SLAAltaMedia = new TimeSpan(0, int.Parse(oWc[0].Fields["MindServices.SlaProblemaAltaMedia"].Value.ToString()), 0);
                SLAMediaMedia = new TimeSpan(0, int.Parse(oWc[0].Fields["MindServices.SlaProblemaMediaMedia"].Value.ToString()), 0);
                SLABaixaMedia = new TimeSpan(0, int.Parse(oWc[0].Fields["MindServices.SlaProblemaBaixaMedia"].Value.ToString()), 0);

                SLAAltaBaixa = new TimeSpan(0, int.Parse(oWc[0].Fields["MindServices.SlaProblemaAltaBaixa"].Value.ToString()), 0);
                SLAMediaBaixa = new TimeSpan(0, int.Parse(oWc[0].Fields["MindServices.SlaProblemaMediaBaixa"].Value.ToString()), 0);
                SLABaixaBaixa = new TimeSpan(0, int.Parse(oWc[0].Fields["MindServices.SlaProblemaBaixaBaixa"].Value.ToString()), 0);




                SLAAltaUtil = bool.Parse(oWc[0].Fields["MindServices.SlaIncidenteAltaUtil"].Value.ToString());
                SLAMediaUtil = bool.Parse(oWc[0].Fields["MindServices.SlaIncidenteMediaUtil"].Value.ToString());
                SLABaixaUtil = bool.Parse(oWc[0].Fields["MindServices.SlaIncidenteBaixaUtil"].Value.ToString());


                SLAAltaAltaUtil = bool.Parse(oWc[0].Fields["MindServices.SlaProblemaAltaAltaUtil"].Value.ToString());
                SLAMediaAltaUtil = bool.Parse(oWc[0].Fields["MindServices.SlaProblemaMediaAltaUtil"].Value.ToString());
                SLABaixaAltaUtil = bool.Parse(oWc[0].Fields["MindServices.SlaProblemaBaixaAltaUtil"].Value.ToString());

                SLAAltaMediaUtil = bool.Parse(oWc[0].Fields["MindServices.SlaProblemaAltaMediaUtil"].Value.ToString());
                SLAMediaMediaUtil = bool.Parse(oWc[0].Fields["MindServices.SlaProblemaMediaMediaUtil"].Value.ToString());
                SLABaixaMediaUtil = bool.Parse(oWc[0].Fields["MindServices.SlaProblemaBaixaMediaUtil"].Value.ToString());

                SLAAltaBaixaUtil = bool.Parse(oWc[0].Fields["MindServices.SlaProblemaAltaBaixaUtil"].Value.ToString());
                SLAMediaBaixaUtil = bool.Parse(oWc[0].Fields["MindServices.SlaProblemaMediaBaixaUtil"].Value.ToString());
                SLABaixaBaixaUtil = bool.Parse(oWc[0].Fields["MindServices.SlaProblemaBaixaBaixaUtil"].Value.ToString());

            }
            

        }

        private int workItemID;

        private const string SlaRespostaField = "MindServices.LimiteResposta";
        private const string SlaAtendimentoField = "MindServices.LimiteCorrecao";
        private const string BugField = "MindServices.Classificacao";
        private const string SeveridadeField = "MindServices.Severidade";
        private const string ComplexidadeSeveridadeField = "MindServices.ComplexidadeSeveridade";
        
        private const string InicioPausaField = "MindServices.InicioPausa";
        private const string TempoPausadoField = "MindServices.TempoPausado";

        private const string DataInicioField = "MindServices.DataHoraResposta";
        //private const string DataInicioField = "System.CreatedDate";


        private const int InicioDiaUtil = 9;
        private const int FimDiaUtil = 18;


        //private const string TempoPausadoField= "MindServices.InicioPausa";
        //private const string InicioPausaField = "MindServices.TempoPausado";



        private  TimeSpan SLABug = new TimeSpan(2,0,0);
        private  TimeSpan SLAResposta = new TimeSpan(0, 10, 0);        

        private  TimeSpan SLAAlta = new TimeSpan(3, 0, 0);
        private  TimeSpan SLAMedia = new TimeSpan(4, 0, 0);
        private  TimeSpan SLABaixa = new TimeSpan(5, 0, 0);


        private  TimeSpan SLAAltaAlta = new TimeSpan(3, 0, 0);
        private  TimeSpan SLAMediaAlta = new TimeSpan(4, 0, 0);
        private  TimeSpan SLABaixaAlta = new TimeSpan(5, 0, 0);

        private  TimeSpan SLAAltaMedia = new TimeSpan(3, 0, 0);
        private  TimeSpan SLAMediaMedia = new TimeSpan(4, 0, 0);
        private  TimeSpan SLABaixaMedia = new TimeSpan(5, 0, 0);

        private  TimeSpan SLAAltaBaixa = new TimeSpan(3, 0, 0);
        private  TimeSpan SLAMediaBaixa = new TimeSpan(4, 0, 0);
        private  TimeSpan SLABaixaBaixa = new TimeSpan(5, 0, 0);



        private bool SLAAltaUtil =true;
        private bool SLAMediaUtil = true;
        private bool SLABaixaUtil = true;


        private bool SLAAltaAltaUtil = true;
        private bool SLAMediaAltaUtil = true;
        private bool SLABaixaAltaUtil = true;

        private bool SLAAltaMediaUtil = true;
        private bool SLAMediaMediaUtil = true;
        private bool SLABaixaMediaUtil = true;

        private bool SLAAltaBaixaUtil = true;
        private bool SLAMediaBaixaUtil = true;
        private bool SLABaixaBaixaUtil = true;



        public  void CalculaSLA(string oldState, string newState)
        {
            if (newState == "Forwarded" && oldState != "Forwarded")
                PausaChamado();
            if (oldState == "Forwarded" && newState != "Forwarded")
                DesPausaChamado();
            if (newState == "Pending" && oldState != "Pending")
                PausaChamado();
            if (oldState == "Pending" && newState != "Pending")
                DesPausaChamado();

                                 
           DefineSlaInicial();
        }

        private  void DefineSlaInicial()
        {


            DateTime oldResposta = new DateTime();
            if (oWi.Fields[SlaRespostaField].Value != null)
                oldResposta = (DateTime)oWi.Fields[SlaRespostaField].Value;
            DateTime oldAtendimento = new DateTime();
            if(oWi.Fields[SlaAtendimentoField].Value != null)
                oldAtendimento=(DateTime) oWi.Fields[SlaAtendimentoField].Value;

            oWi.Fields[SlaRespostaField].Value = oWi.CreatedDate.Add(SLAResposta);

            if (oWi.Fields[DataInicioField].Value == null)
            {
                if (oldResposta.ToShortTimeString() != ((DateTime)oWi.Fields[SlaRespostaField].Value).ToShortTimeString())
                    oWi.Save();
                return;
            }

            if (oWi.Fields[BugField].Value.ToString() == "Incidente")
            {
                switch (oWi.Fields[SeveridadeField].Value.ToString())
                {
                    case "Alta":
                        oWi.Fields[SlaAtendimentoField].Value = CalculaData((DateTime)oWi.Fields[DataInicioField].Value, SLAAlta,SLAAltaUtil,long.Parse(oWi.Fields[TempoPausadoField].Value.ToString()));
                        break;
                    case "Média":
                        oWi.Fields[SlaAtendimentoField].Value = CalculaData((DateTime)oWi.Fields[DataInicioField].Value, SLAMedia, SLAMediaUtil, long.Parse(oWi.Fields[TempoPausadoField].Value.ToString()));
                        break;
                    case "Baixa":
                        oWi.Fields[SlaAtendimentoField].Value = CalculaData((DateTime)oWi.Fields[DataInicioField].Value, SLABaixa, SLABaixaUtil, long.Parse(oWi.Fields[TempoPausadoField].Value.ToString()));
                        break;
                }                
            }
            else
            {
                switch (oWi.Fields[ComplexidadeSeveridadeField].Value.ToString())
                {
                    case "Alta":
                        switch (oWi.Fields[SeveridadeField].Value.ToString())
                        {
                            case "Alta":
                                oWi.Fields[SlaAtendimentoField].Value = CalculaData((DateTime)oWi.Fields[DataInicioField].Value, SLAAltaAlta, SLAAltaAltaUtil, long.Parse(oWi.Fields[TempoPausadoField].Value.ToString()));
                                break;
                            case "Média":
                                oWi.Fields[SlaAtendimentoField].Value = CalculaData((DateTime)oWi.Fields[DataInicioField].Value, SLAAltaMedia, SLAAltaMediaUtil, long.Parse(oWi.Fields[TempoPausadoField].Value.ToString()));
                                break;
                            case "Baixa":
                                oWi.Fields[SlaAtendimentoField].Value = CalculaData((DateTime)oWi.Fields[DataInicioField].Value, SLAAltaBaixa, SLAAltaBaixaUtil, long.Parse(oWi.Fields[TempoPausadoField].Value.ToString()));
                                break;
                        }  
                        break;
                    case "Média":
                        switch (oWi.Fields[SeveridadeField].Value.ToString())
                        {
                            case "Alta":
                                oWi.Fields[SlaAtendimentoField].Value = CalculaData((DateTime)oWi.Fields[DataInicioField].Value, SLAMediaAlta, SLAMediaAltaUtil, long.Parse(oWi.Fields[TempoPausadoField].Value.ToString()));
                                break;
                            case "Média":
                                oWi.Fields[SlaAtendimentoField].Value = CalculaData((DateTime)oWi.Fields[DataInicioField].Value, SLAMediaMedia, SLAMediaMediaUtil, long.Parse(oWi.Fields[TempoPausadoField].Value.ToString()));
                                break;
                            case "Baixa":
                                oWi.Fields[SlaAtendimentoField].Value = CalculaData((DateTime)oWi.Fields[DataInicioField].Value, SLAMediaBaixa, SLAMediaBaixaUtil, long.Parse(oWi.Fields[TempoPausadoField].Value.ToString()));
                                break;
                        }  
                        break;
                    case "Baixa":
                       switch (oWi.Fields[SeveridadeField].Value.ToString())
                        {
                            case "Alta":
                                oWi.Fields[SlaAtendimentoField].Value = CalculaData((DateTime)oWi.Fields[DataInicioField].Value, SLABaixaAlta, SLABaixaAltaUtil, long.Parse(oWi.Fields[TempoPausadoField].Value.ToString()));
                                break;
                            case "Média":
                                oWi.Fields[SlaAtendimentoField].Value = CalculaData((DateTime)oWi.Fields[DataInicioField].Value, SLABaixaMedia, SLABaixaMediaUtil, long.Parse(oWi.Fields[TempoPausadoField].Value.ToString()));
                                break;
                            case "Baixa":
                                oWi.Fields[SlaAtendimentoField].Value = CalculaData((DateTime)oWi.Fields[DataInicioField].Value, SLABaixaBaixa, SLABaixaBaixaUtil, long.Parse(oWi.Fields[TempoPausadoField].Value.ToString()));
                                break;
                        }  
                        break;
                }
            }
            if (oldAtendimento.ToShortTimeString() != ((DateTime)oWi.Fields[SlaAtendimentoField].Value).ToShortTimeString() || oldResposta.ToShortTimeString() != ((DateTime)oWi.Fields[SlaRespostaField].Value).ToShortTimeString())
                oWi.Save();
            
        }
        
        private  void PausaChamado()
        {
          
            oWi.Fields[InicioPausaField].Value = DateTime.Now;
            oWi.Save();


        }

        private  void DesPausaChamado()
        {
          
            oWi.Fields[TempoPausadoField].Value = long.Parse(oWi.Fields[TempoPausadoField].Value.ToString()) + DateTime.Now.Subtract(((DateTime)oWi.Fields[InicioPausaField].Value)).Ticks;
            oWi.Save();
        }

        private DateTime CalculaData(DateTime Database, TimeSpan sla, bool HoraUtil, long Pausa)
        {
            if (HoraUtil)
            {
                return AdicionaBH(AdicionaBH(Database, sla), new TimeSpan(Pausa));
            }
            else
            {
                return Database.Add(sla).AddTicks(Pausa);
            }

        }

        private DateTime AdicionaBH(DateTime d, TimeSpan s)
        {
            for (int i = 0; i < s.TotalMinutes; i++)
            {
                d = d.AddMinutes(1);
                if (!EhHoraUtil(d))
                    i--;
            }
            return d;
        }

        private bool EhHoraUtil(DateTime d)
        {
            if (d.DayOfWeek == DayOfWeek.Saturday)
                return false;
            if (d.DayOfWeek == DayOfWeek.Sunday)
                return false;
            if (d.Hour >= FimDiaUtil)
                return false;
            if (d.Hour < InicioDiaUtil)
                return false;

            List<DateTime> lista = RetornaFeriados();
            var fer = lista.FirstOrDefault(c => c.DayOfYear == d.DayOfYear && c.Year == d.Year);
            if (fer.Ticks > 0)
                return false;
            
            return true;
        }


        private List<DateTime> RetornaFeriados ()
        {

            var feriados = new List<DateTime>();

            //ano novo
            feriados.Add(new DateTime(DateTime.Today.Year, 1,1));
            feriados.Add(new DateTime(DateTime.Today.Year+1, 1, 1));

            //tiradentes
            feriados.Add(new DateTime(DateTime.Today.Year, 4, 21));
            feriados.Add(new DateTime(DateTime.Today.Year + 1, 4, 21));

            //dia do trabalho
            feriados.Add(new DateTime(DateTime.Today.Year, 5, 1));
            feriados.Add(new DateTime(DateTime.Today.Year + 1, 5, 1));

            //independencia
            feriados.Add(new DateTime(DateTime.Today.Year, 9, 7));
            feriados.Add(new DateTime(DateTime.Today.Year + 1, 9, 7));

            //nsa
            feriados.Add(new DateTime(DateTime.Today.Year, 10, 12));
            feriados.Add(new DateTime(DateTime.Today.Year + 1, 10, 12));

            //finados
            feriados.Add(new DateTime(DateTime.Today.Year, 11, 2));
            feriados.Add(new DateTime(DateTime.Today.Year + 1, 11, 2));

            //republic
            feriados.Add(new DateTime(DateTime.Today.Year, 11, 15));
            feriados.Add(new DateTime(DateTime.Today.Year + 1, 11, 15));



            //zombie
            feriados.Add(new DateTime(DateTime.Today.Year, 11, 20));
            feriados.Add(new DateTime(DateTime.Today.Year + 1, 11, 20));


            //natal
            feriados.Add(new DateTime(DateTime.Today.Year, 12, 25));
            feriados.Add(new DateTime(DateTime.Today.Year + 1, 12, 25));


            //revolucao
            feriados.Add(new DateTime(DateTime.Today.Year, 7, 9));
            feriados.Add(new DateTime(DateTime.Today.Year + 1, 7, 9));


            //sexta feira santa
            feriados.Add(new DateTime(2012, 4, 6));
            feriados.Add(new DateTime(2013, 3, 29));
            feriados.Add(new DateTime(2014, 4, 18));
            feriados.Add(new DateTime(2015, 4, 3));
            feriados.Add(new DateTime(2016, 3, 25));
            feriados.Add(new DateTime(2017, 4, 14));
            feriados.Add(new DateTime(2018, 3, 30));
            feriados.Add(new DateTime(2019, 4, 19));
            feriados.Add(new DateTime(2020, 4, 10));


            //carnaval
            feriados.Add(new DateTime(2012, 2, 21));
            feriados.Add(new DateTime(2013, 2, 12));
            feriados.Add(new DateTime(2014, 3, 4));
            feriados.Add(new DateTime(2015, 2, 17));
            feriados.Add(new DateTime(2016, 2, 9));
            feriados.Add(new DateTime(2017, 2, 28));
            feriados.Add(new DateTime(2018, 2, 13));
            feriados.Add(new DateTime(2019, 3, 5));
            feriados.Add(new DateTime(2020, 2, 25));

            feriados.Add(new DateTime(2012, 2, 20));
            feriados.Add(new DateTime(2013, 2, 11));
            feriados.Add(new DateTime(2014, 3, 3));
            feriados.Add(new DateTime(2015, 2, 14));
            feriados.Add(new DateTime(2016, 2, 8));
            feriados.Add(new DateTime(2017, 2, 27));
            feriados.Add(new DateTime(2018, 2, 12));
            feriados.Add(new DateTime(2019, 3, 4));
            feriados.Add(new DateTime(2020, 2, 24));



            //corpus christ           

            feriados.Add(new DateTime(2012, 6, 7));
            feriados.Add(new DateTime(2013, 5, 30));
            feriados.Add(new DateTime(2014, 6, 19));
            feriados.Add(new DateTime(2015, 6, 4));
            feriados.Add(new DateTime(2016, 5, 26));
            feriados.Add(new DateTime(2017, 6, 15));
            feriados.Add(new DateTime(2018, 5, 31));
            feriados.Add(new DateTime(2019, 6, 20));
            feriados.Add(new DateTime(2020, 6, 11));


            return feriados;


        }
    }

    

}