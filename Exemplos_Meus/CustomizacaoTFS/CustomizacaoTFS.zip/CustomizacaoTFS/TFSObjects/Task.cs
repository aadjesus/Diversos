﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using System.Xml;


namespace TFSObjects
{
    public class Task
    {
        int workItemID{get;set;}
        private WorkItem oWi;
        private WorkItem oCR;
        private WorkItemStore store;


        private const string TaskName = "_Tarefa";
        private const string CRName = "_Demanda";
        private const string TipoTaskName = "Microsoft.VSTS.Common.Discipline";


        
        public Task(int WorkItemID)
        {
            workItemID = WorkItemID;
            var ts = Utilitarios.ConectaTFS();
             store = (WorkItemStore)ts.GetService(typeof(WorkItemStore));
            oWi = store.GetWorkItem(workItemID);
            oCR = store.GetWorkItem(workItemID);

        }

        public void BuscaCR()
        {

            for(int i = 0; i < oWi.WorkItemLinks.Count; i++)
            {
                int id = oWi.WorkItemLinks[i].SourceId;
                if (id != workItemID)
                {
                    var cr = store.GetWorkItem(id);
                    if (cr.Fields[CoreField.WorkItemType].Value.ToString() == CRName)
                    {
                        oCR = cr;
                        return;
                    }
                }
                id = oWi.WorkItemLinks[i].TargetId;
                if (id != workItemID)
                {
                    var cr = store.GetWorkItem(id);
                    if (cr.Fields[CoreField.WorkItemType].Value.ToString() == CRName)
                    {
                        oCR = cr;
                        return;
                    }
                }    
            }
        }

        public void ExcluiWI(bool primeira)
          {

            for (int i = 0; i < oWi.WorkItemLinks.Count; i++)
            {
                int id = oWi.WorkItemLinks[i].SourceId;
                if (id != workItemID)
                {
                    var task = store.GetWorkItem(id);
                    if (task.Fields[CoreField.WorkItemType].Value.ToString() == TaskName)
                    {

                        task.Fields[CoreField.State].Value = "Cancelada";
                        task.Save();
                    }
                }
                id = oWi.WorkItemLinks[i].TargetId;
                if (id != workItemID)
                {
                    var task = store.GetWorkItem(id);
                    if (task.Fields[CoreField.WorkItemType].Value.ToString() == TaskName)
                    {
                        task.Fields[CoreField.State].Value = "Cancelada";
                        task.Save();
                    }
                }
            }
        }

        public void EditaWI(bool AlterouDescription)
        {
            for (int i = 0; i < oCR.WorkItemLinks.Count; i++)
            {
                var target = store.GetWorkItem(oCR.WorkItemLinks[i].TargetId);
                var source = store.GetWorkItem(oCR.WorkItemLinks[i].SourceId);

                if (target.Fields[CoreField.WorkItemType].Value.ToString() == TaskName)
                {

                    target.Fields[CoreField.IterationId].Value = oCR.Fields[CoreField.IterationId].Value;
                    target.Fields[CoreField.AreaId].Value = oCR.Fields[CoreField.AreaId].Value;
                    target.Fields["BGMRodotec.Classificacao"].Value = oCR.Fields["BGMRodotec.Classificacao"].Value.ToString();
                    if (AlterouDescription)
                    {
                        target.Fields["Microsoft.VSTS.CMMI.Justification"].Value = target.Fields["Microsoft.VSTS.CMMI.Justification"].Value .ToString()  +  "<BR><BR>[Demanda Alterada " + source.Id + "] <br>" + source.Fields[CoreField.Description].Value.ToString().Replace("\n", "<BR>") + "<br>";
                        oCR.Fields["Microsoft.VSTS.CMMI.Justification"].Value = oCR.Fields["Microsoft.VSTS.CMMI.Justification"].Value.ToString() + "<BR><BR>[Demanda Alterada " + source.Id + "] <br>" + source.Fields[CoreField.Description].Value.ToString().Replace("\n", "<BR>") + "<br>";
                    }
                    oCR.Save();
                    target.Save();
                }
                   
                
                if (source.Fields[CoreField.WorkItemType].Value.ToString() == TaskName)
                {
                    source.Fields[CoreField.IterationId].Value = oCR.Fields[CoreField.IterationId].Value;
                    source.Fields[CoreField.AreaId].Value = oCR.Fields[CoreField.AreaId].Value;
                    source.Fields["BGMRodotec.Classificacao"].Value = oCR.Fields["BGMRodotec.Classificacao"].Value.ToString();
                    if (AlterouDescription)
                    {
                        source.Fields["Microsoft.VSTS.CMMI.Justification"].Value = "[Demanda Alterada " + target.Id + "] <br>" + target.Fields[CoreField.Description].Value.ToString().Replace("\n", "<BR>") + "<br>";
                        oCR.Fields["Microsoft.VSTS.CMMI.Justification"].Value = oCR.Fields["Microsoft.VSTS.CMMI.Justification"].Value.ToString() + "<BR><BR>[Demanda Alterada " + source.Id + "] <br>" + source.Fields[CoreField.Description].Value.ToString().Replace("\n", "<BR>") + "<br>";
                    }
                    source.Save();
                    oCR.Save();
                }
            }
        }

        public bool ExisteTask(tipoTask tpTask)
        {

            for (int i = 0; i < oCR.WorkItemLinks.Count; i++)
            {

                var target = store.GetWorkItem(oCR.WorkItemLinks[i].TargetId);
                if (target.Fields[CoreField.WorkItemType].Value.ToString() == TaskName)
                    if (target.Fields[TipoTaskName].Value.ToString() == StringValueAttribute.GetStringValue(tpTask))
                        if (target.Fields[CoreField.State].Value.ToString() != "Rejeitada")
                            return true;

                var source = store.GetWorkItem(oCR.WorkItemLinks[i].SourceId);
                if (source.Fields[CoreField.WorkItemType].Value.ToString() == TaskName)
                    if (source.Fields[TipoTaskName].Value.ToString() == StringValueAttribute.GetStringValue(tpTask))
                        if (source.Fields[CoreField.State].Value.ToString() != "Rejeitada")
                            return true;
        }

            return false;
        }

        public void CriaProximaTask(bool primeira, bool Anterior)
        {
            tipoTask TipoTask;

            if (Anterior)
            {
                TipoTask = AnteriorTipo((tipoTask)int.Parse(oWi.Fields[TipoTaskName].Value.ToString().Substring(0, 1)), oCR.Fields["BGMRodotec.Orcamento"].Value.ToString());

            }
            else
            {
                if (primeira)
                    TipoTask = tipoTask.EspecificacaoNegocio;
                else
                    TipoTask = ProximoTipo((tipoTask)int.Parse(oWi.Fields[TipoTaskName].Value.ToString().Substring(0, 1)), oCR.Fields["BGMRodotec.Orcamento"].Value.ToString());

                if (ExisteTask(TipoTask))
                    return;

            }

            if (TipoTask == tipoTask.Ultima)
                return;


            var wItem = new WorkItem(oWi.Project.WorkItemTypes[TaskName]);

            wItem.Title = "[" +  oCR.Id + "] - " + StringValueAttribute.GetStringValue(TipoTask);
            wItem.Fields[TipoTaskName].Value = StringValueAttribute.GetStringValue(TipoTask);
            
            wItem.Fields[CoreField.IterationId].Value = oCR.Fields[CoreField.IterationId].Value;
            wItem.Fields[CoreField.AreaId].Value = oCR.Fields[CoreField.AreaId].Value;
            wItem.Fields["BGMRodotec.Classificacao"].Value = oCR.Fields["BGMRodotec.Classificacao"].Value.ToString();
            

            if(TipoTask == tipoTask.EspecificacaoNegocio)
            {
                wItem.Fields["BGMRodotec.Dano"].Value = "Média";
                wItem.Fields["BGMRodotec.Probabilidade"].Value = "Média";
                wItem.Fields["BGMRodotec.Risco"].Value = 0;
            }
            else
            {
                if (TipoTask != tipoTask.EspecificacaoTecnica)
                {
                    wItem.Fields["BGMRodotec.EstimativaTeste"].Value = BuscaFieldEmTaskCorrelata(tipoTask.EspecificacaoTecnica, oCR, "BGMRodotec.EstimativaTeste");
                    wItem.Fields["BGMRodotec.EstimativaDesenvolvimento"].Value = BuscaFieldEmTaskCorrelata(tipoTask.EspecificacaoTecnica, oCR, "BGMRodotec.EstimativaDesenvolvimento");
                    try
                    {
                        wItem.Fields["BGMRodotec.EstimativaTotal"].Value = double.Parse(wItem.Fields["BGMRodotec.EstimativaTeste"].Value.ToString()) + double.Parse(wItem.Fields["BGMRodotec.EstimativaDesenvolvimento"].Value.ToString());
                    }
                    catch { }
                }

                wItem.Fields["BGMRodotec.Dano"].Value = BuscaFieldEmTaskCorrelata(tipoTask.EspecificacaoNegocio, oCR, "BGMRodotec.Dano");
                wItem.Fields["BGMRodotec.Probabilidade"].Value = BuscaFieldEmTaskCorrelata(tipoTask.EspecificacaoNegocio, oCR, "BGMRodotec.Probabilidade");
                wItem.Fields["BGMRodotec.Risco"].Value = CalculaRisco(wItem.Fields["BGMRodotec.Dano"].Value.ToString(), wItem.Fields["BGMRodotec.Probabilidade"].Value.ToString());
            }
            if(TipoTask == tipoTask.Testes)
            {
                wItem.Fields["BGMRodotec.Previsto"].Value = BuscaFieldEmTaskCorrelata(tipoTask.EspecificacaoTecnica, oCR, "BGMRodotec.EstimativaTeste");
                wItem.Fields["BGMRodotec.Restante"].Value = BuscaFieldEmTaskCorrelata(tipoTask.EspecificacaoTecnica, oCR, "BGMRodotec.EstimativaTeste");
            }

            if(TipoTask == tipoTask.Desenvolvimento)
            {
                wItem.Fields["BGMRodotec.Previsto"].Value = BuscaFieldEmTaskCorrelata(tipoTask.EspecificacaoTecnica, oCR, "BGMRodotec.EstimativaDesenvolvimento");
                wItem.Fields["BGMRodotec.Restante"].Value = BuscaFieldEmTaskCorrelata(tipoTask.EspecificacaoTecnica, oCR, "BGMRodotec.EstimativaDesenvolvimento");
            }
            
            //adicionar demais campos

            //wItem.Fields[CoreField.AssignedTo].Value = BuscaResponsavel(oCR.Fields[CoreField.AreaPath].Value.ToString(), TipoTask);

            if (oWi.Fields[CoreField.Id].Value.ToString() != oCR.Fields[CoreField.Id].Value.ToString())
            {
                if(!primeira)
                    AtualizaOrcamento();
                oCR.Fields["Microsoft.VSTS.CMMI.Justification"].Value = oCR.Fields["Microsoft.VSTS.CMMI.Justification"].Value.ToString() + "<br>" + oWi.Fields[TipoTaskName].Value.ToString() + "<br>" + oWi.Fields[CoreField.Description].Value.ToString().Replace("\n", "<BR>") + "<br>";
                oCR.Save();
            }
            else
            {
                if (!primeira)
                    AtualizaOrcamento();
                oCR.Fields["Microsoft.VSTS.CMMI.Justification"].Value = "[Demanda " + oCR.Id + "] <br>" + oCR.Fields[CoreField.Description].Value.ToString().Replace("\n", "<BR>") + "<br>";
                oCR.Save();
            }

            wItem.Fields["Microsoft.VSTS.CMMI.Justification"].Value = oCR.Fields["Microsoft.VSTS.CMMI.Justification"].Value.ToString();
            wItem.Fields["BGMRodotec.Orcamento"].Value = oCR.Fields["BGMRodotec.Orcamento"].Value.ToString();

            wItem.Save();
            wItem.WorkItemLinks.Add(new WorkItemLink(store.WorkItemLinkTypes.LinkTypeEnds["Parent"],oCR.Id));
            wItem.Save();
        }

        public static string BuscaResponsavel(string areaPath, tipoTask tpTask)
        {
            
            string path=@"C:\WS-BGMRodotec\xml\assign.xml";
            XmlDocument doc = new XmlDocument();
            using (System.IO.StreamReader r = new System.IO.StreamReader(path))
            {
                doc.Load(path);            
                foreach (XmlNode node in doc.ChildNodes[1].ChildNodes)
                {
                    if (node["modulotarefa"].InnerText == areaPath && node["tipotarefa"].InnerText.Trim() == StringValueAttribute.GetStringValue(tpTask))
                        return node["responsavelTarefa"].InnerXml;
                }
                return "";
            }
        }

        public int CalculaRisco(string Dano, string Probabilidade)
        {
            Dano = Dano.ToUpper();
            Probabilidade = Probabilidade.ToUpper();
            switch (Dano)
            {
                case "ALTA":
                    switch (Probabilidade)
                    {
                        case "ALTA":
                            return 9;
                        case "MÉDIA":
                            return 8;                            
                        case "BAIXA":
                            return 6;                            
                    }
                    break;
                case "MÉDIA":
                    switch (Probabilidade)
                    {
                        case "ALTA":
                            return 7;
                        case "MÉDIA":
                            return 5;
                        case "BAIXA":
                            return 3;
                    }
                    break;
                case "BAIXA":
                    switch (Probabilidade)
                    {
                        case "ALTA":
                            return 4;
                        case "MÉDIA":
                            return 2;
                        case "BAIXA":
                            return 1;
                    }
                    break;
            }

            return 0;
        }


        public string BuscaFieldEmTaskCorrelata(tipoTask tpTask, WorkItem cr, string Field)
        {
            string ret = "";
            int id = 0;


            for (int i = 0; i < oCR.WorkItemLinks.Count; i++)
            {
                var target = store.GetWorkItem(oCR.WorkItemLinks[i].TargetId);
                var source = store.GetWorkItem(oCR.WorkItemLinks[i].SourceId);

                if (target.Fields[CoreField.WorkItemType].Value.ToString() == TaskName)
                {
                    if (target.Fields[TipoTaskName].Value.ToString() == StringValueAttribute.GetStringValue(tpTask))
                    {
                        if(int.Parse(target.Fields[CoreField.Id].Value.ToString()) > 0)
                        {
                            id = int.Parse(target.Fields[CoreField.Id].Value.ToString());
                            ret = target.Fields[Field].Value.ToString();
                        }
                    }

                }

                if (source.Fields[CoreField.WorkItemType].Value.ToString() == TaskName)
                {
                    if (source.Fields[TipoTaskName].Value.ToString() == StringValueAttribute.GetStringValue(tpTask))
                    {
                        if (int.Parse(source.Fields[CoreField.Id].Value.ToString()) > 0)
                        {

                            id = int.Parse(source.Fields[CoreField.Id].Value.ToString());
                            ret = source.Fields[Field].Value.ToString();
                        }
                    }

                }
            }


            return ret;
        }

        private tipoTask ProximoTipo(tipoTask tpTask, string requerOrcamento)
        {
            if (tpTask == tipoTask.EspecificacaoNegocio)
                return tipoTask.EspecificacaoTecnica;
            if (tpTask == tipoTask.EspecificacaoTecnica)
                if (requerOrcamento == "Não")
                    return tipoTask.Desenvolvimento;
                else
                    return tipoTask.Comercial;
            if (tpTask == tipoTask.Comercial)
                return tipoTask.Desenvolvimento;
            if (tpTask == tipoTask.Desenvolvimento)
                return tipoTask.Testes;
            if (tpTask == tipoTask.Testes)
                return tipoTask.DisponibilizacaoCliente;
            return tipoTask.Ultima;
        }

        private tipoTask AnteriorTipo(tipoTask tpTask, string requerOrcamento)
        {
            if (tpTask == tipoTask.EspecificacaoTecnica)
                return tipoTask.EspecificacaoNegocio;
            if (tpTask == tipoTask.Comercial)
                return tipoTask.EspecificacaoTecnica;

            if (tpTask == tipoTask.Desenvolvimento)
                if (requerOrcamento == "Não")
                    return tipoTask.EspecificacaoTecnica;
                else
                    return tipoTask.Comercial;


            if (tpTask == tipoTask.Testes)
                return tipoTask.Desenvolvimento;
            if (tpTask == tipoTask.DisponibilizacaoCliente)
                return tipoTask.Testes;
            return tipoTask.Ultima;
        }
        

        public enum tipoTask
        {
            [StringValue("1- Especificação de Negócio")]
            EspecificacaoNegocio=1,
            [StringValue("2- Especificação Técnica")]
            EspecificacaoTecnica = 2,
            [StringValue("3- Comercial")]
            Comercial = 3,
            [StringValue("4- Desenvolvimento")]
            Desenvolvimento = 4,
            [StringValue("5- Testes")]
            Testes = 5,
            [StringValue("6- Disponibilização ao Cliente")]
            DisponibilizacaoCliente = 6,
            [StringValue("Ultima")]
            Ultima = 7
        }

        public class StringValueAttribute : System.Attribute
        {

            private string _value;

            public StringValueAttribute(string value)
            {
                _value = value;
            }

            public string Value
            {
                get { return _value; }
            }


            public static string GetStringValue(Enum value)
            {
                string output = null;
                Type type = value.GetType();
                System.Reflection.FieldInfo fi = type.GetField(value.ToString());
                StringValueAttribute[] attrs = fi.GetCustomAttributes(typeof(StringValueAttribute), false) as StringValueAttribute[];
                if (attrs.Length > 0)
                    output = attrs[0].Value;
                return output;
            }
        }



        public void AtualizaOrcamento()
        {
            if (oWi.Fields[TipoTaskName].Value.ToString() == StringValueAttribute.GetStringValue(tipoTask.EspecificacaoNegocio))
            {
                oCR.Fields["BGMRodotec.Orcamento"].Value = oWi.Fields["BGMRodotec.Orcamento"].Value.ToString();
            }
        }

        public bool VerificaAlteracaoDescription(int NewRev, int OldRev)
        {
            var Old = store.GetWorkItem(this.oWi.Id,OldRev);
            var New = store.GetWorkItem(this.oWi.Id, NewRev);
            return Old.Description != New.Description;
            
            
        }
    }
}
