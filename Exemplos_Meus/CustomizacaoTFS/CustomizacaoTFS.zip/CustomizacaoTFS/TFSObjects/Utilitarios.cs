﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.TeamFoundation.Client;
using System.Net;
using System.Configuration;

namespace TFSObjects
{
    public class Utilitarios
    {
        public static TfsTeamProjectCollection ConectaTFS()
        {
            string usr = ConfigurationManager.AppSettings["usr"];
            string psw = ConfigurationManager.AppSettings["psw"];
            Uri TFS= new Uri(System.Configuration.ConfigurationManager.AppSettings["TFSURI"]);       
            


            int ind = usr.IndexOf('\\');
            string usuario, dominio;
            NetworkCredential credentials;


            if (ind > 0)
            {
                dominio = usr.Substring(0, ind);
                usuario = usr.Substring(ind + 1);
                credentials = new NetworkCredential(usuario, psw, dominio);
            }
            else
            {
                if (usr == "")
                    credentials = System.Net.CredentialCache.DefaultNetworkCredentials;                    
                else
                    credentials = new NetworkCredential(usr, psw);
            }


            return new TfsTeamProjectCollection(TFS, credentials);
            
        }
    }
}
